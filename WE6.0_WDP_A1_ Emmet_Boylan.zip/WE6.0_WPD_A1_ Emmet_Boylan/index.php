<?php
/**
* @filename: index.php
* @Author: Emmet Boylan (emmet.boylan@webelevate.ie)
* @project: WE6.0_WPD_A1
* @file description: A simple php controller file. The default address and start point for the application
*/
//include the webform class
include_once 'webform.class.php';
//instantiate webform class
$w = new WebForm();
?>