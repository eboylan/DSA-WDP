This is a simple application to generate unit data for a strategy game
set in the BattleTech universe.
The statistics generated are for use in that game and may not make much sense
out of context. However, understanding the context is not neccesary to
understand the program flow.
index.php is the default start point.

The application does not include complex features such as databases or a
method of saving and reviewing generated data, beyond displaying the 
data as a web page. However such functionality can be added at a later date.